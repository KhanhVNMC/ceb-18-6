@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\\CEB\\ceb-launcher.ps1" -Mode h -Url "%~1"
exit