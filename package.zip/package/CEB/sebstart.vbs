Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -File ""C:\CEB\ceb-launcher.ps1"" -Mode h -Url """ & WScript.Arguments(0) & """", 0, False