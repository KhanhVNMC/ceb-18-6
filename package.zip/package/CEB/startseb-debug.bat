@echo off
frida.exe -f "C:\Program Files\SafeExamBrowser\Application\SafeExamBrowser.exe" -l "C:\CEB\cebbsp.js" -- C:\Users\GiaKhanhVN\Downloads\SebClientSettings.seb
