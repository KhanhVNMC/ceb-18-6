param(
    [ValidateSet("h", "v")] 
    [string]$Mode = "v", # verbose
    [string]$Url
)

$LogFile = "C:\\CEB\\info.log"
$Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

if ($Mode -eq "h") { 
    $windowStyle = 'Hidden'
} else {
    $windowStyle = 'Normal'
}
$FridaArgs = "-f `"C:\Program Files\SafeExamBrowser\Application\SafeExamBrowser.exe`" -l `"C:\CEB\cebbsp.js`" -- $Url"
$LogEntry = "[$Timestamp] Mode: $windowStyle | Launching: 'frida.exe $FridaArgs'"
Add-Content -Path $LogFile -Value $LogEntry
Start-Process frida.exe -ArgumentList $FridaArgs -WindowStyle $windowStyle
Exit