import frida
import time
import subprocess
import sys

TARGET = "SafeExamBrowser.exe"
SCRIPT_PATH = r"C:\\CEB\\cebbsp.js"

def wait_for_process(device):
    pid = None
    while pid is None:
        try:
            process = device.get_process(TARGET)
            pid = process.pid
        except frida.ProcessNotFoundError:
            time.sleep(0.01)
    return pid

def main():
    print(f"[*] Continuous polling for {TARGET}...")
    device = frida.get_local_device()
    while True:
        pid = wait_for_process(device)
        print(f"[*] Found {TARGET} (PID: {pid})! Launching Frida CLI...")
        cmd = [
            "frida",
            "-p", str(pid),
            "-l", SCRIPT_PATH
        ]
        try:
            subprocess.run(cmd)
            print("[*] Frida session ended. Returning to polling...")
        except KeyboardInterrupt:
            print("\n[*] Exiting...")
            break
        time.sleep(0.1)

if __name__ == "__main__":
    main()