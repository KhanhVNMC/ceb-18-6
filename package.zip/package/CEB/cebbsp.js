// CONFIG PATHS
const CLR_PATH_OVERRIDES = {
    "\.browser\.dll$": "C:\\CEB\\ceblib0.dll",
    "\.proctoring\.dll$": "C:\\CEB\\ceblib1.dll"
};
const FRIDA_SCRIPT_SOURCE = "C:\\CEB\\cebbsp.js"
// CONFIG FLAGS
const USE_LEGACY_PATCHING_CODE_PATH = false; // dont change
const PARANOIA_OVERDRIVE = true; // "in case of fire break glass ahh"
const CHILD_WAIT_FOR_FRIDA_DELAY = 3; // seconds
const SHOW_CHILD_FRIDA_CONSOLE = false;
const CHILD_FRIDA_CONSOLE_PERSISTENT = false;
// DEBUG INFO
const LOG_LOADED_LIBRARIES = false;
const INTEGRITY_MODULE_VERBOSE = false;

// guards
if (typeof Frida === 'undefined' || typeof Process === 'undefined' || typeof window !== 'undefined') {
    throw new Error("[SEB PATCHER] Are you running this script in a fucking browser??");
}

if (typeof CLR_PATH_OVERRIDES === 'undefined' || typeof FRIDA_SCRIPT_SOURCE === 'undefined') {
    throw new Error("[SEB PATCHER] This script is not configured properly!");
}

if (typeof CLR_PATH_OVERRIDES !== 'object' || Array.isArray(globalThis.CLR_PATH_OVERRIDES)) {
    throw new Error("[SEB PATCHER] CLR_PATH_OVERRIDES must be an object (pattern -> replacement map)");
}

// patch frida
// safe method to get module without blowing up mid way
Process.getModuleByNameNoEx = (args) => {
    try { // no throw
        return Process.getModuleByName(args);
    } catch {
        return null;
    }
}

const COMPILED_PATTERNS = Object.entries(CLR_PATH_OVERRIDES).map(([p, override]) => {
    const struct = {
        pattern: new RegExp(p, "i"),
        overrideBy: override
    };
    if (struct.pattern.test(override)) {
        console.warn(`[SEB PATCHER] The override path "${override}" matches its own pattern "${p}". `
            + `This is dangerous and could lead to unforeseen... consequences!`
        );
    }
    return struct;
});

const win32 = {
    sigs: {}, // signatures (addresses), non exec
    funcs: {} // full blown functions, marshalled to JS
}; // base

const natives = {
    sigs: {}, // signatures (addresses), non exec
    funcs: {}, // unused
}; // for future versions (SEB 4.xx)

// consts
const nullptr = ptr(0);
const TRUE = 1, FALSE = 0;

const IS_64_BIT_WINDOWS = Process.pointerSize === 8;
const FRIDA_PATH = "C:\\Windows\\System32\\cmd.exe /c frida.exe";

/**
 * This function hooks onto NtCreateUserProcess to detect when SEB Runtime launches
 * the main client SafeExamBrowser.Client.exe (which is the main point of interest)
 * and then hook a new Frida instance onto it
 */
function hookOnNTUserCreateProcess() {
    console.log("[SEB PATCHER] Hooking into NtCreateUserProcess...");
    Interceptor.attach(win32.sigs.NtCreateUserProcess, {
        shouldLaunchFrida: false, // true if the created process is indeed SEB client
        processHandlePtr: null, // PHANDLE

        // https://captmeelo.com/redteam/maldev/2022/05/10/ntcreateuserprocess.html
        // args for NtCreateUserProcess
        // 0: PHANDLE ProcessHandle (pointer to HANDLE) << point of interest
        // 1: PHANDLE ThreadHandle
        // 2: ProcessDesiredAccess (uint32)
        // 3: ThreadDesiredAccess (uint32)
        // 4: ProcessObjectAttributes
        // 5: ThreadObjectAttributes
        // 6: ProcessFlags (uint32)
        // 7: ThreadFlags (uint32)
        // 8: PRTL_USER_PROCESS_PARAMETERS ProcessParameters << point of interest
        // 9: PPS_CREATE_INFO CreateInfo
        // 10: PPS_ATTRIBUTE_LIST AttributeList
        onEnter(args) {
            const processParams = args[8]; // this is the bullshit known as PRTL_USER_PROCESS_PARAMETERS
            if (processParams.isNull()) {
                return; // this should NEVER happen
            }
            this.processHandlePtr = args[0]; // this is used to grab the process ID later on
            const unicodeOffset = IS_64_BIT_WINDOWS ? 0x70 : 0x40;
            const unicodeStruct = processParams.add(unicodeOffset);

            // get the pointer of the passed cmd
            const commandLinePtr = unicodeStruct.add(Process.pointerSize).readPointer();
            if (commandLinePtr.isNull()) {
                return; // sometimes this happens
            }

            const command = commandLinePtr.readUtf16String();
            if (command && command.toLowerCase().includes(".client.exe")) { // straightforward
                this.shouldLaunchFrida = true;
                console.log("[SEB PATCHER] Detected SEB Client launch command:", command)
            }
        },

        onLeave(returnValue) {
            // only runs if the process is SEB Client AND it is successful
            if (!this.shouldLaunchFrida || returnValue.toInt32() !== 0) {
                return;
            }
            // obtain the process id so frida knows where to hook
            const spawnedHandle = this.processHandlePtr.readPointer();
            const spawnedProcessId = win32.funcs.GetProcessId(spawnedHandle);

            console.log("[SEB PATCHER] Detected SEB Client! Process ID:", spawnedProcessId);
            console.log("[SEB PATCHER] Attaching Frida to the SEB Client process...");

            if (CHILD_WAIT_FOR_FRIDA_DELAY > 0) {
                win32.funcs.NtSuspendProcess(spawnedHandle);
            }

            // ref material: https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/ns-processthreadsapi-startupinfow
            const STARTUPINFO_SIZE = 68;
            const fridaCmd = Memory.allocUtf16String(`${CHILD_FRIDA_CONSOLE_PERSISTENT ? "cmd.exe /c " : ""}${FRIDA_PATH} -p ${spawnedProcessId} -l ${FRIDA_SCRIPT_SOURCE}${CHILD_FRIDA_CONSOLE_PERSISTENT ? " & pause" : ""}`);

            const struct_STARTUPINFO = Memory.alloc(STARTUPINFO_SIZE);
            // if the user doesn't want another console to launch after the first one
            // setup the frida launch process in a way that does it silently
            if (!SHOW_CHILD_FRIDA_CONSOLE) {
                // si->cb = sizeof(STARTUPINFO)
                struct_STARTUPINFO.writeU32(STARTUPINFO_SIZE);
                // STARTF_USESHOWWINDOW (0x00000001)
                // offset 60 bytes from struct base (dwFlags)
                struct_STARTUPINFO.add(60).writeU32(0x1);
                // wShowWindow = SW_HIDE (0x0), SW_SHOW (0x5)
                // offset 62 bytes from struct base (wShowWindow)
                struct_STARTUPINFO.add(62).writeU16(0x0);
            }

            // 4 pointers: struct PROCESS_INFORMATION { HANDLE a; HANDLE b; DWORD c; DWORD d; }
            const struct_PROCESS_INFORMATION = Memory.alloc(Process.pointerSize * 4);

            const fridaSuccess = win32.funcs.CreateProcessW(
                nullptr, // lpApplicationName
                fridaCmd, // lpCommandLine
                nullptr,  // lpProcessAttribute,
                nullptr, // lpThreadAttribute
                0, // bInheritHandles
                0, // dwCreationFlags (tf?)
                nullptr, // lpEnvironment (ENV)
                nullptr, // lpCurrentDirectory
                struct_STARTUPINFO,
                struct_PROCESS_INFORMATION
            );

            if (fridaSuccess === TRUE) {
                console.log("[SEB PATCHER] Frida has been attached to the SEB Client process!");
                if (CHILD_WAIT_FOR_FRIDA_DELAY > 0) {
                    console.log(`[SEB PATCHER] Suspending Client process for ${CHILD_WAIT_FOR_FRIDA_DELAY}s to allow Frida init...`);
                    Thread.sleep(CHILD_WAIT_FOR_FRIDA_DELAY);
                    console.log("[SEB PATCHER] Resuming SEB Client process threads...");
                    win32.funcs.NtResumeProcess(spawnedHandle);
                }
                return;
            }
            console.error("[SEB PATCHER] Failed to attach Frida to SEB Client process!");
        }
    });
    console.log("[SEB PATCHER] Hooked successfully into NtCreateUserProcess!");
}

// clr.dll, the c# virtual machine (java wannable)
const clrRuntime = {
    clrDll: null,
    clrBase: null, // base address of the loaded dll
    clrEnd: null // top address (exclusive)
};

function hookCreateFileW() {
    console.log("[SEB PATCHER] Hooking into CreateFileW...");
    if (USE_LEGACY_PATCHING_CODE_PATH) {
        // dont use this
        console.warn(
            "[SEB PATCHER] You are using the SLOWER and more DETECTABLE (though battle-tested) CLR patching method!" +
            " Unless you are encountering specific issues, switch to the modern codepath!!!"
        );
    }
    // best effort try (frida hooked too late to catch the LoadLibraryEx call)
    if (!clrRuntime.clrDll) {
        attemptToGetCLRModule();
        attemptToResolveCLRAddresses("(anonymous) clr.dll", true);
    }
    // basically we fool the CLR by moving SEB Browser actual location somewhere else
    // since managed CLR DLLs are NOT real DLL, the CLR is just reading the file using conventional
    // methods
    Interceptor.attach(win32.sigs.CreateFileW, {
        onEnter(args) {
            const returnAddr = this.returnAddress; // RSP -> top of stack frame
            const originalPath = args[0].readUtf16String(); // -> RAX (or EAX)

            if (!originalPath || !returnAddr) {
                return; // wait, how?
            }

            let target = null;
            for (let i = 0; i < COMPILED_PATTERNS.length; ++i) {
                const compiled = COMPILED_PATTERNS[i];
                if (!compiled.pattern.test(originalPath) || originalPath === compiled.overrideBy) {
                    continue; // yikes
                }
                target = compiled; // match what we want to replace
                break;
            };
            if (!target) return; // not what we want
            
            let isCalledByCLR = false, isLegacy = true;
            // support both, just in case
            if (!USE_LEGACY_PATCHING_CODE_PATH) {
                if (clrRuntime.clrDll) { // CLR dll is loaded
                    // check if the function's return address is in CLR's region (CLR called it)
                    if (returnAddr.compare(clrRuntime.clrBase) >= 0 
                    && returnAddr.compare(clrRuntime.clrEnd) < 0
                    ) {
                        isCalledByCLR = true; // definitely
                        isLegacy = false; // this is the new method 
                    }
                }
            } else { // WARNING: THIS CODEPATH IS EXTREMELY SLOW AND OBSOLETE (AND CAN BE DETECTED), THE ONE ABOVE IS BETTER!
                // ============== OBSOLETE CODE ==============
                const backtrace = Thread.backtrace(this.context, Backtracer.ACCURATE); // it turns out that FUZZY doesnt work reliably on this
                const maxTraceFrames = Math.min(24, backtrace.length) // 24 maximum stack steppings
                // walk back the thread callstack to see what DLL, EXE called this api
                for (let i = 0; i < maxTraceFrames; ++i) {
                    try {
                        const addr = backtrace[i];
                        const module = Process.getModuleByAddress(addr);
                        if (isCalledByCLR && (module && (module.name === "seb_x64.dll" || module.name === "seb_x86.dll"))) {
                            console.warn(
                                `[SEB PATCHER] CLR Patch ABORTED! SEB integrity module exists within the CLR call stack! (how the f?)`
                            );
                            isCalledByCLR = false;
                            break;
                        }

                        // CLR = Common Language Runtime, C# runtime, which is what SEB is based on
                        if (module && (module.name === "coreclr.dll" || module.name === "clr.dll")) {
                            isCalledByCLR = true;
                            continue;
                        }
                    } catch (ignored) { };
                }
                // ============== OBSOLETE CODE ==============
            }

            // we dont patch files that are not referenced by the CLR
            if (!isCalledByCLR) return;

            // this should NEVER happen if you configured this properly
            const overrideBy = target.overrideBy;
            if (originalPath.length >= overrideBy.length + 1) {
                args[0].writeUtf16String(`${overrideBy}\0`);
                console.log(`[SEB PATCHER] Patched CLR: Replaced "${originalPath}" with "${overrideBy}" in-place! (${isLegacy ? "Stack Walking" : "Return Slurping"})`);
            } else {
                console.error(
                    `[SEB PATCHER] Cannot CLR-patch "${originalPath}" with "${overrideBy}": `
                    + `The replacement path is too long for the original buffer!`
                );
            }
        },

        onLeave() { /* not much to do here... */ }
    });
}

// attempt to find CLR.dll (or coreclr in some jackass version)
function attemptToGetCLRModule() {
    return Process.getModuleByNameNoEx("clr.dll") || Process.getModuleByNameNoEx("coreclr.dll");
}

// resolve the low/upper bounds region of memory that CLR.dll is loaded at
function attemptToResolveCLRAddresses(normalizedPath, found = false) {
    if (!clrRuntime.clrDll) {
        return;
    }
    clrRuntime.clrBase = clrRuntime.clrDll.base;
    clrRuntime.clrEnd = clrRuntime.clrDll.base.add(clrRuntime.clrDll.size);
    console.log(`[SEB PATCHER] SEB Runtime "${normalizedPath}" ${found ? "found" : "loaded"} in process memory: ${clrRuntime.clrBase} -> ${clrRuntime.clrEnd} (Size: ${clrRuntime.clrDll.size} bytes)`);
}

function hookOnNTLoadLibraryExW() {
    console.log("[SEB PATCHER] Hooking into LoadLibraryExW...");
    Interceptor.attach(win32.sigs.LoadLibraryExW, {
        onEnter: function (args) {
            this.path = args[0].readUtf16String();
        },
        onLeave: function (retval) {
            if (retval.isNull()) return; // load failed, shit
            if (this.path) {
                const normalizedPath = this.path?.toLowerCase();
                if (LOG_LOADED_LIBRARIES) {
                    console.log("[DEBUG: DLL] " + this.path + " loaded at address: " + retval);
                }
                // find the C# runtime (CLR, Common Language Runtime)
                if (!clrRuntime.clrDll && normalizedPath && (
                    normalizedPath.includes("clr.dll") || normalizedPath.includes("coreclr.dll")
                )) {
                    clrRuntime.clrDll = attemptToGetCLRModule();
                    // this is only true once the module is actually loaded
                    if (clrRuntime.clrDll) {
                        attemptToResolveCLRAddresses(this.path, false);
                    } else {
                        // not in the PEB yet, warn so i no paranoid
                        console.warn(`[SEB PATCHER] SEB Runtime "${this.path}" mapped at ${retval} but not in PEB. Retrying next call...`);
                    }
                }
                // if found seb_xXX dll, register signatures and funcs (if needed)
                if (!natives.sebdll && normalizedPath && (
                    normalizedPath.includes("seb_x64.dll") || normalizedPath.includes("seb_x86.dll") // support both 32 and 64 bit
                )) {
                    // the dll itself
                    natives.sebdll = Process.getModuleByNameNoEx("seb_x64.dll") || Process.getModuleByNameNoEx("seb_x86.dll");
                    if (!natives.sebdll) {
                        console.error("[SEB PATCHER] Cannot load SEB integrity module DLL! This script may not behave as expected.");
                        return;
                    }

                    // import addresses of seb_xXX.dll functions (some may be null, depending on SEB version)
                    natives.sigs.VerifyCodeSignature = natives.sebdll.findExportByName("VerifyCodeSignature");
                    natives.sigs.VerifyRuntimeIntegrity = natives.sebdll.findExportByName("VerifyRuntimeIntegrity");
                    natives.sigs.IsVirtualMachine = natives.sebdll.findExportByName("IsVirtualMachine");

                    // inject hooks
                    forceReturnBool("SEB::VerifyCodeSignature", natives.sigs.VerifyCodeSignature, 
                        (PARANOIA_OVERDRIVE || USE_LEGACY_PATCHING_CODE_PATH) ? TRUE // force true
                        : undefined // only observe if not paranoid OR in legacy path
                    ); 
                    forceReturnBool("SEB::VerifyRuntimeIntegrity", natives.sigs.VerifyRuntimeIntegrity, TRUE);
                    forceBypassVMChecks(natives.sigs.IsVirtualMachine, true);
                }
            }
        }
    });

    function forceReturnBool(name, signature, retValOverride) {
        console.log(`[SEB PATCHER] Hooking into ${name}...`);
        if (!signature) {
            console.warn(`[SEB PATCHER] Integrity module function '${name}' is missing, you can safely ignore this.`);
            return;
        }
        Interceptor.attach(signature, {
            onEnter: function (args) {
                if (INTEGRITY_MODULE_VERBOSE) console.log(`[VERBOSE] Integrity module function "${name}" called.`);
            },
            onLeave: function (retval) {
                let original = retval.toInt32();
                if (retValOverride === undefined) {
                    if (INTEGRITY_MODULE_VERBOSE) {
                        console.log(`[VERBOSE] Return value of "${name}" is: ${original}`);
                    }
                    return;
                }
                if (INTEGRITY_MODULE_VERBOSE) {
                    console.log(`[VERBOSE] Retval of "${name}" modified. Original: ${original} -> forced: ${retValOverride != 0 ? 1 : 0}.`);
                }
                retval.replace(ptr(retValOverride != 0 ? TRUE : FALSE));
            }
        });
        console.log(`[SEB PATCHER] Hooked successfully into ${name}!`);
    }

    function forceBypassVMChecks(signature, bypass = false) {
        console.log(`[SEB PATCHER] Hooking into SEB::IsVirtualMachine...`);
        if (!signature) {
            console.warn(`[SEB PATCHER] Integrity module function 'SEB::IsVirtualMachine' is missing, you can safely ignore this...?`);
            return;
        }
        Interceptor.attach(signature, {
            onEnter: function (args) {
                if (INTEGRITY_MODULE_VERBOSE) console.log(`[VERBOSE] Integrity module function "SEB::IsVirtualMachine" called.`);
                // (IntPtr* manufacturer, int* probability) parameters
                this.manufacturerPtrPtr = args[0]; // IntPtr*
                this.probabilityPtr = args[1]; // int*
            },
            onLeave: function (retval) {
                const originalBool = retval.toInt32(); // original values
                const originalProbability = this.probabilityPtr.readInt();
                const manufacturerBase = this.manufacturerPtrPtr.readPointer();
                let originalManufacturer = "undefined";
                if (!manufacturerBase.isNull()) {
                    originalManufacturer = manufacturerBase.readUtf16String();
                    if (originalManufacturer.length == 0) {
                        originalManufacturer = "null (zero-len string)";
                    }
                }
                if (INTEGRITY_MODULE_VERBOSE) {
                    console.log(`[VERBOSE] "SEB::IsVirtualMachine" function result:`);
                    console.log(`  => Original Verdict: ${originalBool != 0 ? "YES" : "NO"}`);
                    console.log(`  => Original Probability: ${originalProbability}%`);
                    console.log(`  => Original Vendor: ${originalManufacturer}`);
                    if (bypass) console.log(`=> FORCED VERDICT: NO`);
                }
                if (bypass) {
                    // return modified values
                    this.probabilityPtr.writeInt(0); // probability = 0
                    this.manufacturerPtrPtr.writePointer(nullptr); // manufacturer = nullptr
                    retval.replace(ptr(FALSE)); // return false
                }
            }
        });
        console.log(`[SEB PATCHER] Hooked successfully into SEB::IsVirtualMachine!`);
    }
    console.log("[SEB PATCHER] Hooked successfully into LoadLibraryExW!");
}

function main(args) {
    console.log("[SEB PATCHER] Attempting to launch the script...");
    console.log("[SEB PATCHER] Importing Win32 (WinNT) libraries...");
    // IMPORT win32 libraries
    win32.kernel32 = Process.getModuleByNameNoEx('kernel32.dll') || Process.getModuleByNameNoEx('kernelbase.dll');
    win32.ntdll = Process.getModuleByNameNoEx('ntdll.dll');
    win32.kernelbase = Process.getModuleByNameNoEx('kernelbase.dll');

    if (!win32.kernel32 || !win32.ntdll || !win32.kernelbase) {
        console.error("[SEB PATCHER] This SEB patching script needs Windows NT based operating systems!");
        return;
    }

    // import the addresses interested functions
    win32.sigs.CreateProcessW = win32.kernel32.getExportByName("CreateProcessW");
    win32.sigs.GetProcessId = win32.kernel32.getExportByName("GetProcessId");
    win32.sigs.CreateFileW = win32.kernel32.getExportByName("CreateFileW");
    win32.sigs.NtCreateUserProcess = win32.ntdll.getExportByName("NtCreateUserProcess");
    win32.sigs.NtSuspendProcess = win32.ntdll.getExportByName("NtSuspendProcess");
    win32.sigs.NtResumeProcess = win32.ntdll.getExportByName("NtResumeProcess");
    win32.sigs.LoadLibraryExW = win32.kernelbase.getExportByName('LoadLibraryExW');

    // marshal these functions so they can be used in JS
    win32.funcs.CreateProcessW = new NativeFunction(
        win32.sigs.CreateProcessW,
        "bool",
        ["pointer", "pointer", "pointer", "pointer", "bool", "uint32", "pointer", "pointer", "pointer", "pointer"]
    );
    win32.funcs.GetProcessId = new NativeFunction(
        win32.sigs.GetProcessId,
        "uint32", ["pointer"]
    );
    win32.funcs.NtSuspendProcess = new NativeFunction(
        win32.sigs.NtSuspendProcess,
        "uint32", ["pointer"]
    );
    win32.funcs.NtResumeProcess = new NativeFunction(
        win32.sigs.NtResumeProcess,
        "uint32", ["pointer"]
    );

    // inject necessary hooks
    try {
        hookOnNTUserCreateProcess();
        hookCreateFileW();
        hookOnNTLoadLibraryExW();
    } catch (e) {
        console.error("[SEB PATCHER] Error! Failed to hook:", e);
    }
}

/* Entrypoint of the script */
rpc.exports = {
    init(stage, parameters) {
        main(parameters)
    },
    dispose() {
        log('[dispose]');
    }
};