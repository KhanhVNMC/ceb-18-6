if (!window.mainLoaded) { (function() {
// Constants
const UPPER_LEFT = 0; const UPPER_RIGHT = 1; const LOWER_RIGHT = 2; const LOWER_LEFT = 3;

// Known hosts
const CEB_SERVER_HOSTS = ["scopenoracle.mooo.com", "27.72.234.229", "127.0.0.1"];

// CEBServer related configurations
const HOST = "localhost"; const PORT = 8086; 
const CLIENT_IDENTIFIER = "SEBClientBrowser";
const PREFERRED_MODEL = "openai:gpt-5.5";

// initialization
window.mainLoaded = true;
(function () {
    function load(key) { try { return Number(localStorage.getItem(key)) || 0; } catch { return 0; } }
    function save(key, v) { try { localStorage.setItem(key, String(v >>> 0)); } catch {} }

    const UI_KEY = "_barley";
    window.uiDataSystem = {
        // position: 0–255 (8-bit)
        setPosition(pos) {
            pos = pos & 0xFF;
            let state = load(UI_KEY);
            state = (state & ~0xFF) | pos;
            save(UI_KEY, state);
        },
        // hidden stored in bit 8
        setHidden(hidden) {
            let state = load(UI_KEY);
            if (hidden) {
                state |= (1 << 8);
            } else {
                state &= ~(1 << 8);
            }
            save(UI_KEY, state);
        },
        // show in title stored in bit 9
        setShowInTitle(show) {
            let state = load(UI_KEY);
            if (show) {
                state |= (1 << 9);
            } else {
                state &= ~(1 << 9);
            }
            save(UI_KEY, state);
        },
        getPosition() { return load(UI_KEY) & 0xFF; },
        isHidden() { return (load(UI_KEY) & (1 << 8)) !== 0; },
        isShowInTitle() { return (load(UI_KEY) & (1 << 9)) !== 0; }
    };

    const PSCEB_KEY = "_hardtack";
    const PSCEB_OVERRIDE_KEY = "_shipbiscuit";
    window.psCeb = {
        // last known good host inside a list of available hosts
        setLKGCebServerIdx(domainIdx) { save(PSCEB_KEY, domainIdx); },
        getLKGCebServerIdx(domain) { return load(PSCEB_KEY); },
        // override
        setCebServerOverride(domain) { try { localStorage.setItem(PSCEB_OVERRIDE_KEY, domain); } catch {} },
        getCebServerOverride() { try { return localStorage.getItem(PSCEB_OVERRIDE_KEY) || "-1"; } catch { return "-1" } }
    };
})();

// prevent sentry (if any)
println = console.log;
errPrintln = console.error;
warnPrintln = console.warn;

// boilerplate to setup the output system
function setOutputResult(text) {
    resultBox.textContent = text;
    resultBox.title = text;
    if (_writeOutputToTitle) {
        document.title = text;
    }
};
let _writeOutputToTitle = false;
let _previousTitle = document.title;
function setWriteOutputToTitle(enable) {
    if (_writeOutputToTitle === enable) return;
    if (enable) {
        _previousTitle = document.title; // always backup the most current title
        document.title = resultBox.textContent || "Ready!";
    } else {
        document.title = _previousTitle; // restore safely
    }
    _writeOutputToTitle = enable;
    window.uiDataSystem.setShowInTitle(enable);
}
window.setOutputResult = setOutputResult; // expose to the assistant system

// HANDLED by CEB SERVER
function connectWithFailover(onSuccess, onError) {
    let override = window.psCeb.getCebServerOverride();
    let targetHost = HOST;

    if (override && override !== "-1") {
        targetHost = override === "0" ? "127.0.0.1" : override;
    } else {
        let idx = window.psCeb.getLKGCebServerIdx();
        targetHost = CEB_SERVER_HOSTS[idx % CEB_SERVER_HOSTS.length];
    }

    native.cebServer.tryConnect(targetHost, PORT, CLIENT_IDENTIFIER, 
        (/* on success */) => {
            onSuccess();
        }, 
        (error) => {
            // passive failover: only shift if automatic routing is used
            if (!override || override === "-1") {
                let nextIdx = (window.psCeb.getLKGCebServerIdx() + 1) % CEB_SERVER_HOSTS.length;
                window.psCeb.setLKGCebServerIdx(nextIdx);
                warnPrintln(`[CEB SERVER] ${targetHost} failed. Passive failover shifted LKG index to ${nextIdx}.`);
            }
            if (onError) onError(error, targetHost);
        }
    );
}

window.assistantAPI = {
    _submitToAICebServer: (queryType, payloadData, reasoningEffort) => {
        window.setOutputResult("Preparing...");
        // connect if not already (this will NOT reconnect if alr connected)
        connectWithFailover((/* on success */) => {
            // then dispatch request
            native.cebServer.sendRequest("ai", 
                {
                    preferred_model: PREFERRED_MODEL,
                    query_type: queryType,
                    payload: payloadData,
                    reasoning_effort: reasoningEffort
                },
                (cid) => window.setOutputResult("Thinking..."),
                (success) => {
                    let responseText = success.payload;
                    if (success.fallback_model) { // notice the user if it fell back
                        warnPrintln(`[CEB: AI] [${PREFERRED_MODEL}] Using fallback model: ${success.fallback_model}`);
                        responseText = `[FB] ${responseText}`;
                    }
                    println(`[CEB: AI] [${PREFERRED_MODEL}] Success! Model Response:`, success);
                    window.setOutputResult(responseText);
                },
                (error) => {
                    errPrintln(`[CEB: AI] [${PREFERRED_MODEL}] Failed to query LLM model(s):`, error);
                    window.setOutputResult(`Error: ${error.error || error}`);
                }
            );
        }, (/* on error */ error, failedHost) => {
            errPrintln(`[CEB SERVER] Cannot connect to CEB Server at ${failedHost}! Error:`, error);
            window.setOutputResult(`CSError (${failedHost}): ${String(error)}`);
        });
    },

    submitNormalTextToAssistant(text, reasoningEffort = "low") {
        this._submitToAICebServer("TEXT", text, reasoningEffort);
    },
    
    submitImageToAssistant(base64Image, reasoningEffort = "medium") {
        this._submitToAICebServer("IMAGE", base64Image, reasoningEffort);
    },

    getAssistantProvider: () => { return "CEBServer LLMs Router"; },
    getAssistantAIModel:  () => { return PREFERRED_MODEL; }
};

// bookkeeping for global values
let capsLockOn = false;
let pos1 = null, pos2 = null;
let ctrlPressed = false;
let shiftPressed = false;

// create the overlay to visualize the selection
const overlay = document.createElement('div');
Object.assign(overlay.style, {
    position: 'absolute',
    background: 'rgba(0, 153, 255, 0)',
    border: "1px dashed rgba(127, 127, 127, 0.12)",
    mixBlendMode: "difference",
    pointerEvents: 'none',
    zIndex: 9999999,
    display: 'none'
});

// create the secret div to put the assistant/js result in
const resultBox = document.createElement("div");
Object.assign(resultBox.style, {
    fontSize: "initial",
    fontFamily: "system-ui",
    position: "fixed",
    top: "0",
    right: "0",
    width: "50%",
    padding: "6px",
    background: "transparent",
    color: "transparent",
    textAlign: "right",
    zIndex: 999999
});

// create the secret input box to use Assistant Text or JS commands
const inputBox = document.createElement("input");
Object.assign(inputBox.style, {
    fontSize: "initial",
    fontFamily: "system-ui",
    position: "fixed",
    bottom: "8px",
    left: "0",
    width: "25%",
    padding: "8px",
    background: "transparent",
    color: "black",
    border: "none",
    outline: "none",
    zIndex: 999999,
});
inputBox.spellcheck = false;

// helper func
function onWebLoad() {
    document.documentElement.appendChild(overlay);
    document.documentElement.appendChild(resultBox);
    document.documentElement.appendChild(inputBox);
    applyResultBoxUI();
    setWriteOutputToTitle(window.uiDataSystem.isShowInTitle());
    setOutputResult("Ready!");
}

// sync to localstorage
function applyResultBoxUI() {
    const isHidden = window.uiDataSystem.isHidden();
    resultBox.style.display = isHidden ? "none" : "block";

    const pos = window.uiDataSystem.getPosition();
    switch (pos) {
        case UPPER_LEFT:
            resultBox.style.top = "0px";
            resultBox.style.left = "0px";
            resultBox.style.right = "auto";
            resultBox.style.bottom = "auto";
            resultBox.style.textAlign = "left";
            break;
        case UPPER_RIGHT:
            resultBox.style.top = "0px";
            resultBox.style.left = "auto";
            resultBox.style.right = "0px";
            resultBox.style.bottom = "auto";
            resultBox.style.textAlign = "right";
            break;
        case LOWER_RIGHT:
            resultBox.style.top = "auto";
            resultBox.style.left = "auto";
            resultBox.style.right = "0px";
            resultBox.style.bottom = "8px";
            resultBox.style.textAlign = "right";
            break;
        case LOWER_LEFT:
            resultBox.style.top = "auto";
            resultBox.style.left = "0px";
            resultBox.style.right = "auto";
            resultBox.style.bottom = "40px"; // make room for the textinput
            resultBox.style.textAlign = "left";
            break;
    }
}

// insert on ready
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", onWebLoad);
} else {
    onWebLoad();
}

// listen for CTRL + SHIFT hold to change the pigment
window.addEventListener("keydown", (e) => {
    if (e.key === "Control") ctrlPressed = true;
    if (e.key === "Shift") shiftPressed = true;
    if (ctrlPressed && shiftPressed) {
        resultBox.style.color = "white";
    }
});

window.addEventListener("keyup", (e) => {
    if (e.key === "Control") ctrlPressed = false;
    if (e.key === "Shift") shiftPressed = false;
    // when either released, reset to white
    if (!ctrlPressed || !shiftPressed) {
        resultBox.style.color = "transparent";
    }
});

// command history support
const commandHistory = [];
let historyIndex = -1;

function addToHistory(cmd) {
    if (cmd.trim() === "") return;
    if (commandHistory[commandHistory.length - 1] !== cmd) {
        commandHistory.push(cmd);
    }
    historyIndex = commandHistory.length;
}

const jsTriggers = ["js:", "javascript:", "j:"];
// listen for when the user enter something
inputBox.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
        let command = inputBox.value;
        inputBox.value = ""; // clear the box

        if (!command) return;
        addToHistory(command);

        if (command === "!c") { // clear the output box immediately
            setOutputResult("");
            return;
        }

        let isJS = false;
        for (const prefix of jsTriggers) {
            if (command.toLowerCase().startsWith(prefix)) {
                command = command.slice(prefix.length); // remove the prefix
                isJS = true; // this is a js command
                break;
            }
        }

        // execute as javascript
        if (isJS) {
            let output = "";
            try {
                output = eval(command);
            } catch (err) {
                output = err.toString(); // handle errors so it wont die
            } finally {
                setOutputResult(output); // print out
            }
            return;
        }
        // send to assistant
        const reasoningEffort = e.shiftKey ? "high" : "medium";
        println(`[Assistant-From-Console Module] Sending to ASSISTANT: ${command} (effort: ${reasoningEffort})`);
        assistantAPI.submitNormalTextToAssistant(command, reasoningEffort);
    }
    // history system
    if (e.key === "ArrowUp") {
        e.preventDefault();
        if (historyIndex > 0) {
            historyIndex--; // move up
            inputBox.value = commandHistory[historyIndex] ?? "";
        }
    } else if (e.key === "ArrowDown") {
        e.preventDefault();
        if (historyIndex < commandHistory.length - 1) {
            historyIndex++; // move down
            inputBox.value = commandHistory[historyIndex] ?? "";
        } else {
            historyIndex = commandHistory.length;
            inputBox.value = ""; // at the end
        }
    }
});

document.addEventListener("keydown", (e) => {
    // CHANGE OUTPUT MODE
    if (e.altKey && e.shiftKey) {
        // allow it to write to the browser's title too
        if (e.key === "q" || e.key === "Q") {
            e.preventDefault();
            setWriteOutputToTitle(!_writeOutputToTitle);
            return;
        }
        // ping the server
        if (e.key === "p" || e.key === "P") {
            e.preventDefault();
            window.setOutputResult("Pinging...");
            connectWithFailover(() => {
                const startTime = performance.now();
                native.cebServer.sendRequest("ping", {}, 
                    (cid) => {
                        // ACK received
                        const latency = Math.round(performance.now() - startTime);
                        window.setOutputResult(`Pong! Latency: ${latency}ms`);
                    },
                    null, // ping doesn't use the Success block
                    (error) => {
                        window.setOutputResult(`Ping Error: ${error.error || error}`);
                    }
                );
            }, (error, failedHost) => {
                window.setOutputResult(`CSError (${failedHost}): Cannot ping`);
            });
            return;
        }
        // custom server
        if (e.key === "l" || e.key === "L") {
            e.preventDefault();
            let current = window.psCeb.getCebServerOverride();
            let promptVal = prompt("-1 = Auto (Default)\n0 = localhost\nOr enter a custom domain/IP:", current);
            if (promptVal !== null && promptVal.trim() !== "") {
                window.psCeb.setCebServerOverride(promptVal.trim());
                native.cebServer.disconnect(); // force disconnect so next request uses new host
                window.setOutputResult(`Host override set: '${promptVal}'`);
            }
            return;
        }
    }
    
    // CLEAR OUTPUT BOX, EMERGENCY!
    if (e.altKey && (e.key === "c" || e.key === "C")) {
        e.preventDefault();
        inputBox.value = ""; // empty the window
        inputBox.blur(); // stop the blinking cursor
        setOutputResult(""); // just empty it out
        setWriteOutputToTitle(false); // reset output, if any
        return;
    }

    // TOGGLE OUTPUT BOX VISIBILITY
    if (e.altKey && (e.key === "x" || e.key === "X")) {
        e.preventDefault();
        const currentlyHidden = window.uiDataSystem.isHidden();
        window.uiDataSystem.setHidden(!currentlyHidden);
        applyResultBoxUI();
        return;
    }

    // MOVE OUTPUT BOX AROUND
    if (e.ctrlKey && e.altKey) {
        let pos = window.uiDataSystem.getPosition();
        let changed = false;
        if (e.key === "ArrowUp") {
            if (pos === LOWER_LEFT) { pos = UPPER_LEFT; changed = true; }
            if (pos === LOWER_RIGHT) { pos = UPPER_RIGHT; changed = true; }
        } else if (e.key === "ArrowDown") {
            if (pos === UPPER_LEFT) { pos = LOWER_LEFT; changed = true; }
            if (pos === UPPER_RIGHT) { pos = LOWER_RIGHT; changed = true; }
        } else if (e.key === "ArrowLeft") {
            if (pos === UPPER_RIGHT) { pos = UPPER_LEFT; changed = true; }
            if (pos === LOWER_RIGHT) { pos = LOWER_LEFT; changed = true; }
        } else if (e.key === "ArrowRight") {
            if (pos === UPPER_LEFT) { pos = UPPER_RIGHT; changed = true; }
            if (pos === LOWER_LEFT) { pos = LOWER_RIGHT; changed = true; }
        }
        if (changed) {
            // update the gui 
            e.preventDefault();
            window.uiDataSystem.setPosition(pos);
            applyResultBoxUI();
            return;
        }
    }
});

// ====== BEGIN SCREENSHOT => ANSWER PIPELINE ======
let _dragging = false;

document.addEventListener("mousedown", (e) => {
    if (!capsLockOn) return;
    if (!e.shiftKey || e.button !== 0) return;
    e.preventDefault(); // do not interact w/ the page
    _dragging = true; // we're in dragging mode
    pos1 = {
        x: e.clientX,
        y: e.clientY
    };
    pos2 = { ...pos1 }; // copy of pos1
    highlightRegion(pos1.x, pos1.y, pos2.x, pos2.y);
});

document.addEventListener("mousemove", (e) => {
    if (!_dragging) return;
    if (!capsLockOn || !e.shiftKey) return;
    // update pos2 according to the current mouse position
    pos2 = {
        x: e.clientX,
        y: e.clientY
    };
    highlightRegion(pos1.x, pos1.y, pos2.x, pos2.y);
});

document.addEventListener("mouseup", () => {
    _dragging = false; // no longer dragging
});

// user can scroll and it can mess shit up, so update accordingly
window.addEventListener("scroll", () => {
    highlightRegion(pos1?.x, pos1?.y, pos2?.x, pos2?.y);
});

document.addEventListener("contextmenu", (e) => {
    if (!capsLockOn) return;
    if (e.shiftKey) {
        e.preventDefault(); // prevent the rc menu from disturbing us
    }
});

document.addEventListener("keyup", (e) => {
    if (e.key === "Shift") {
        _dragging = false; // no longer dragging altogether
    }
});

// listen for the document for selection
document.addEventListener("keydown", (e) => {
    // update the global caps lock state
    if (e.getModifierState("CapsLock") !== capsLockOn) {
        capsLockOn = e.getModifierState("CapsLock");
        // if caps lock is off, hide the overlay
        if (!capsLockOn) {
            overlay.style.display = 'none';
        } else {
            highlightRegion(pos1?.x, pos1?.y, pos2?.x, pos2?.y);
        }
    }

    // ESC -> reset everything (when there's something)
    if (e.key === "Escape" && pos1 && pos2) {
        e.preventDefault();
        resetRegionSelected();
        return;
    }

    // enter => submit to ASSISTANT
    if (capsLockOn && e.key === "Enter") {
        if (!pos1 || !pos2) return; // incomplete
        const minX = Math.min(pos1.x, pos2.x);
        const minY = Math.min(pos1.y, pos2.y);
        const maxX = Math.max(pos1.x, pos2.x);
        const maxY = Math.max(pos1.y, pos2.y);
        if (maxX - minX < 5 || maxY - minY < 5) return;
        e.preventDefault();
        // submit and pray
        captureScreenshotAndUploadToAssistant(minX, minY, maxX, maxY, e.shiftKey);
    }
});
// ====== END SCREENSHOT => ANSWER PIPELINE ======

/**
 * Capture the screenshot of the given region and send it to
 * the implemented assistant provider's API for processing
 */
function captureScreenshotAndUploadToAssistant(minX, minY, maxX, maxY, shiftKey) {
    resetRegionSelected();
    if (typeof native === 'undefined') throw new Error("Unsupported!");
    native.captureScreenshotDpr(minX, minY, maxX, maxY)
    .then(imageURL => {
        const finalImageURL = imageURL.startsWith("data:image/png;base64,")
            ? imageURL : `data:image/png;base64,${imageURL}`
        ;
        const reasoningEffort = shiftKey ? "high" : "medium";
        println(`[Assistant-From-Image Module] Sending screenshot to ASSISTANT (effort: ${reasoningEffort})`);
        assistantAPI.submitImageToAssistant(finalImageURL, reasoningEffort);
    });
}

/**
 * Reset and hide the visualizer
 */
function resetRegionSelected() {
    pos1 = null;
    pos2 = null;
    overlay.style.display = "none";
}

/**
 * Hightlights the given region  
 */
function highlightRegion(x1, y1, x2, y2) {
    // do NOT display if the region has a null component OR
    // caps lock is OFF
    if (!capsLockOn || x1 == null || y1 == null || x2 == null || y2 == null) {
        overlay.style.display = 'none';
        return;
    }

    // compute the min/max of the bounding box
    const minX = Math.min(x1, x2);
    const minY = Math.min(y1, y2);
    const maxX = Math.max(x1, x2);
    const maxY = Math.max(y1, y2);

    // compute the width / height since CSS bruh
    const width = maxX - minX;
    const height = maxY - minY;

    if (width < 5 || height < 5) { // make sure the region is "reasonably" large
        overlay.style.display = 'none';
        return;
    }

    overlay.style.left = (minX + window.scrollX) + "px";
    overlay.style.top = (minY + window.scrollY) + "px";
    overlay.style.width = width + "px";
    overlay.style.height = height + "px";
    overlay.style.display = 'block';
}

println("[CN-HELPER] Script loaded successfully!");
})(); }