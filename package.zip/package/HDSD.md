## 1. Giao diện

Khi trợ lý đang chạy, bạn sẽ có hai khu vực chính trên màn hình:

* **Hộp nhập (góc dưới bên trái):** Một ô văn bản nhỏ nơi bạn có thể nhập câu hỏi hoặc lệnh.
* **Hộp kết quả:** Khu vực hiển thị nơi câu trả lời của AI xuất hiện. Mặc định, khu vực này bị ẩn (trong suốt) để không gây xao nhãng hoặc bị người khác nhìn thấy.

## 2. Lệnh văn bản & trò chuyện

Để hỏi AI một câu đơn giản, nhấp vào **Hộp nhập** ở góc dưới bên trái màn hình.

* **Gửi câu hỏi:** Nhập câu hỏi và nhấn **Enter**.
* **Chế độ suy nghĩ sâu:** Nếu câu hỏi phức tạp (ví dụ như bài toán khó), giữ **Shift** và nhấn **Enter**. Điều này yêu cầu AI dành nhiều nỗ lực hơn để suy luận câu trả lời.
* **Xem lại câu hỏi trước:** Nhấn **mũi tên lên** hoặc **mũi tên xuống** trong ô nhập để duyệt qua các lệnh đã nhập gần đây, giống như lịch sử terminal.
* **Xóa cuộc trò chuyện:** Nhập `!c` và nhấn **Enter** để xóa ngay câu trả lời hiện tại khỏi màn hình.

## 3. Trình quét ảnh chụp màn hình (phân tích hình ảnh)

Đây là tính năng mạnh nhất của trợ lý. Bạn có thể khoanh một vùng bất kỳ trên màn hình (biểu đồ, đoạn văn, hình ảnh) và gửi trực tiếp cho AI để phân tích.

**Cách chụp và gửi ảnh:**

1. **Bật Caps Lock.** (Trình quét hình ảnh sẽ bị vô hiệu hóa khi Caps Lock tắt để tránh kích hoạt nhầm).

2. **Giữ phím `Shift`.**

3. **Nhấp và kéo** chuột để chọn vùng màn hình cần chụp. Bạn sẽ thấy một khung nét đứt xuất hiện.

4. Thả chuột. (Khung nét đứt sẽ vẫn hiển thị trên màn hình).

5. **Nhấn `Enter`** để gửi hình ảnh đã chọn cho AI.

   * *Mẹo:* Giống như với văn bản, bạn có thể giữ **Shift** và nhấn **Enter** để yêu cầu AI suy nghĩ kỹ hơn về hình ảnh vừa gửi.

6. Khung nét đứt sẽ biến mất và AI bắt đầu xử lý hình ảnh!

**Hủy chụp màn hình:**

* Nếu bạn đã chọn vùng nhưng muốn hủy, chỉ cần nhấn **Escape**.
* Ngoài ra, tắt **Caps Lock** cũng sẽ ngay lập tức ẩn trình quét.

## 4. Tính năng ẩn và quyền riêng tư

Trợ lý được thiết kế để đảm bảo tính kín đáo tối đa. Theo mặc định, câu trả lời của AI hoàn toàn không hiển thị cho đến khi bạn yêu cầu xem.

* **Hiển thị câu trả lời:** Giữ **Ctrl + Shift**. Khi giữ hai phím này, câu trả lời của AI sẽ hiện lên bằng chữ trắng sáng. Khi thả phím, nó sẽ ngay lập tức trở lại trạng thái ẩn.
* **“Nút hoảng loạn” (xóa toàn bộ):** Nhấn **Alt + C**. Đây là thao tác xóa khẩn cấp, xóa ngay ô nhập, câu trả lời AI và đặt lại tiêu đề cửa sổ.
* **Đọc trong tiêu đề tab:** Nhấn **Alt + Shift + Q**. Thay vì đọc trên màn hình, phím tắt này đưa câu trả lời của AI lên thanh tiêu đề tab của trình duyệt ở phía trên cùng. Nhấn lại để tắt.

## 5. Di chuyển và ẩn trợ lý

Bạn có thể tùy chỉnh vị trí hiển thị câu trả lời của AI trên màn hình để không che khuất công việc. Tùy chọn sẽ được lưu tự động.

* **Ẩn hoàn toàn trợ lý:** Nhấn **Alt + X**. Bật/tắt hộp kết quả. Nếu không cần AI, có thể dùng để ẩn hoàn toàn.
* **Di chuyển hộp kết quả:** Giữ **Ctrl + Alt** và nhấn các **phím mũi tên** (lên, xuống, trái, phải) để đưa hộp câu trả lời của AI vào một trong bốn góc màn hình.
* *Ví dụ:* `Ctrl + Alt + mũi tên phải` sẽ đưa nó sang bên phải màn hình. `Ctrl + Alt + mũi tên xuống` sẽ đưa nó xuống phía dưới.
